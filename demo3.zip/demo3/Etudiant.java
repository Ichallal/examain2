package com.example.demo3;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import javafx.scene.layout.VBox;
public class Etudiant {
    private String nom;
    private String prenom;
    private int age;
    private double note1;
    private double note2;
    private ArrayList<Etudiant> listeEtudiants = new ArrayList<Etudiant>();

    public void ajouterEtudiant(String nom, String prenom, int age, double note1, double note2) {
        Etudiant etudiant = new Etudiant();
        etudiant.nom = nom;
        etudiant.prenom = prenom;
        etudiant.age = age;
        etudiant.note1 = note1;
        etudiant.note2 = note2;
        this.listeEtudiants.add(etudiant);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information ajoutée");
        alert.setHeaderText(null);
        alert.setContentText("L'étudiant " + nom + " " + prenom + " a été ajouté avec succès !");
        alert.showAndWait();
    }

    public void afficherEtudiant() {
        String etudiants = "";
        for (Etudiant etudiant : this.listeEtudiants) {
            etudiants += "Nom : " + etudiant.nom + "\nPrénom : " + etudiant.prenom + "\nAge : " + etudiant.age + "\nNote 1 : " + etudiant.note1 + "\nNote 2 : " + etudiant.note2 + "\n\n";
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informations étudiants");
        alert.setHeaderText(null);
        alert.setContentText(etudiants);
        alert.showAndWait();
    }

    public void creerInterfaceGraphique() {
        Stage stage = new Stage();
        stage.setTitle("Etudiant");

        // Créer les éléments de l'interface graphique
        Label nomLabel = new Label("Nom :");
        TextField nomField = new TextField();
        Label prenomLabel = new Label("Prénom :");
        TextField prenomField = new TextField();
        Label ageLabel = new Label("Âge :");
        TextField ageField = new TextField();
        Label note1Label = new Label("Note 1 :");
        TextField note1Field = new TextField();
        Label note2Label = new Label("Note 2 :");
        TextField note2Field = new TextField();
        Button ajouterButton = new Button("Ajouter");
        Button afficherButton = new Button("Afficher");

        // Ajouter un gestionnaire d'événement pour le bouton "Ajouter"
        ajouterButton.setOnAction(e -> {
            // Récupérer les valeurs entrées par l'utilisateur dans les champs de texte
            String nom = nomField.getText();
            String prenom = prenomField.getText();
            int age = Integer.parseInt(ageField.getText());
            double note1 = Double.parseDouble(note1Field.getText());
            double note2 = Double.parseDouble(note2Field.getText());

            // Ajouter l'étudiant
            ajouterEtudiant(nom, prenom, age, note1, note2);

            // Effacer les champs de texte
            nomField.clear();
            prenomField.clear();
            ageField.clear();
            note1Field.clear();
            note2Field.clear();
        });

        // Ajouter un gestionnaire d'événement pour le bouton "Afficher"
        afficherButton.setOnAction(e -> {
            afficherEtudiant();
        });
        // Créer une interface pour les éléments de l'interface graphique
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10));
        // jajoute les element a linterface
        vbox.getChildren().addAll(nomLabel, nomField, prenomLabel, prenomField, ageLabel, ageField, note1Label, note1Field, note2Label, note2Field, ajouterButton, afficherButton);

        // ajouter une fenetre assez normale
        Scene scene = new Scene(vbox);
        stage.setScene(scene);

        // Afficher la fenêtre a la fin
        stage.show();
    }
}


//vraiment je commence a lacher