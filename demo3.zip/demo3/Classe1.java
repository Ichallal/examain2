package com.example.demo3;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
public class Classe1 extends Application {
    private ProfesseurList professeurList;

    private ListView<ProfesseurList.Professeur> listView;

    private TextField nomTextField;
    private TextField prenomTextField;
    private TextField matiereTextField;
    private TextField ancienneteTextField;
    private TextField ageTextField;
    public void start(Stage stage) {
        professeurList = new ProfesseurList();

        GridPane inputGrid = new GridPane();
        inputGrid.setHgap(10);
        inputGrid.setVgap(10);
        inputGrid.setPadding(new Insets(10, 10, 10, 10));

        nomTextField = new TextField();
        prenomTextField = new TextField(); // ajout du champ de texte pour le prenom
        matiereTextField = new TextField(); // ajout du champ de texte pour la matiere
        ancienneteTextField = new TextField(); // ajout du champ de texte pour l'ancienneté
        ageTextField = new TextField();

        inputGrid.add(new Label("Nom:"), 0, 0);
        inputGrid.add(nomTextField, 1, 0);
        inputGrid.add(new Label("Prenom:"), 0, 1); // ajout du label pour le prenom
        inputGrid.add(prenomTextField, 1, 1); // ajout du champ de texte pour le prenom
        inputGrid.add(new Label("Age:"), 0, 2);
        inputGrid.add(ageTextField, 1, 2);
        inputGrid.add(new Label("Matiere:"), 0, 3); // ajout du label pour la matiere
        inputGrid.add(matiereTextField, 1, 3); // ajout du champ de texte pour la matiere
        inputGrid.add(new Label("Anciennete:"), 0, 4); // ajout du label pour l'ancienneté
        inputGrid.add(ancienneteTextField, 1, 4); // ajout du champ de texte pour l'ancienneté


        Button addButton = new Button("Ajouter Professeur");
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                String nom = nomTextField.getText();
                String prenom = prenomTextField.getText(); // récupération du prenom saisi dans le champ de texte correspondant
                String matiere = matiereTextField.getText(); // récupération de la matiere saisie dans le champ de texte correspondant
                int anciennete = 0;
                int age = 0;
                try {
                    age = Integer.parseInt(ageTextField.getText());
                } catch (NumberFormatException e) {
                    showError("Âge invalide!");
                    return;
                }

                professeurList.ajouterProfesseur(nom, prenom,matiere,anciennete ,age);
                nomTextField.setText("");
                ageTextField.setText("");
                listView.setItems(professeurList.getProfesseurs());
            }
        });

        Button displayButton = new Button("Afficher Professeurs");
        displayButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                ObservableList<ProfesseurList.Professeur> professeurs = professeurList.getProfesseurs();
                listView.setItems(professeurs);
            }
        });

        Button clearButton = new Button("Effacer Professeurs");
        clearButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                professeurList.effacerProfesseurs();
                listView.setItems(null);
            }
        });

        VBox inputBox = new VBox();
        inputBox.getChildren().addAll(inputGrid, addButton, displayButton, clearButton);

        listView = new ListView<ProfesseurList.Professeur>();
        listView.setPrefWidth(300);
        listView.setPrefHeight(200);

        HBox mainBox = new HBox();
        mainBox.getChildren().addAll(inputBox, listView);

        Scene scene = new Scene(mainBox);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    private void showError(String errorMessage) {
        System.out.println(errorMessage);
    }
    private class ProfesseurList {

        private ObservableList<Professeur> professeurs;

        public ProfesseurList() {
            professeurs = FXCollections.observableArrayList();
        }
        public void ajouterProfesseur(String nom, String prenom, String matiere, int anciennete ,int age) {
            Professeur professeur = new Professeur(nom,prenom,matiere,anciennete ,age);
            professeurs.add(professeur);
        }

        public void effacerProfesseurs() {
            professeurs.clear();
        }
        public void addProfesseur(String nom, String prenom, String matiere, int anciennete ,int age) {
            Professeur professeur = new Professeur(nom, prenom ,matiere,anciennete,age);
            professeurs.add(professeur);
        }

        public ObservableList<Professeur> getProfesseurs() {
            return professeurs;
        }



        public class Professeur {
            private String nom;
            private String prenom;
            private String matiere;
            private int anciennete;
            private int age;

            public Professeur(String nom, String prenom, String matiere, int anciennete ,int age ) {
                this.nom = nom;
                this.prenom = prenom;
                this.matiere = matiere;
                this.anciennete = anciennete;
                this.age=age;
            }

            public String getNom() {
                return nom;
            }

            public String getPrenom() {
                return prenom;
            }

            public String getMatiere() {
                return matiere;
            }

            public int getAnciennete() {
                return anciennete;
            }

            public String toString() {
                return nom + " " + prenom + ", " + matiere + ", " + anciennete + " années d'ancienneté";
            }
        }
    }}
