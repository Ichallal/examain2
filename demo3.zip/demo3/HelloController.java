package com.example.demo3;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
public class HelloController extends Application {
    public static ArrayList<Element> elements;
    private Label nomLabel;
    private Label prenomLabel;
    private Label quantiteLabel;
    private Label ageLabel;

    private TextField nomField;
    private TextField prenomField;
    private TextField quantiteField;
    private TextField ageField;
    public void start(Stage primaryStage) {
        this.elements = new ArrayList();
        this.nomLabel = new Label("Nom :");
        this.nomField = new TextField();
        this.prenomLabel = new Label("Prénom :");
        this.prenomField = new TextField();
        this.quantiteLabel = new Label("Quantité :");
        this.quantiteField = new TextField();
        this.ageLabel = new Label("Âge :");
        this.ageField = new TextField();
        Button ajouterButton = new Button("Ajouter");
        ajouterButton.setOnAction((e) -> {
            this.ajouterElement();
        });
      //  Button supprimerButton = new Button("Supprimer");
       // supprimerButton.setOnAction((e) -> {
         //   this.supprimerElement();
       // });
        Button afficherButton = new Button("Afficher");
        afficherButton.setOnAction((e) -> {
            Label label=new Label();
            Stage stage = null;
            this.afficherInventaire(label, stage);
        });
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10.0);
        grid.setVgap(10.0);
        grid.setPadding(new Insets(25.0, 25.0, 25.0, 25.0));
        grid.add(this.nomLabel, 0, 1);
        grid.add(this.nomField, 1, 1);
        grid.add(this.prenomLabel, 0, 2);
        grid.add(this.prenomField, 1, 2);
        grid.add(this.quantiteLabel, 0, 3);
        grid.add(this.quantiteField, 1, 3);
        grid.add(this.ageLabel, 0, 4);
        grid.add(this.ageField, 1, 4);
        HBox buttonBox = new HBox();
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setSpacing(10.0);
        buttonBox.getChildren().addAll(new Node[]{ajouterButton, afficherButton});
        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10.0);
        vbox.getChildren().addAll(new Node[]{grid, buttonBox});
        Scene scene = new Scene(vbox, 400.0, 300.0);
        primaryStage.setTitle("Inventaire");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    void ajouterElement() {
        String nom = this.nomField.getText();
        String prenom = this.prenomField.getText();
        int quantite = Integer.parseInt(this.quantiteField.getText());
        int age = Integer.parseInt(this.ageField.getText());
        this.elements = new ArrayList(this.elements);
        Element nouvelElement = new Element(nom, prenom, quantite, age);
        this.elements.add(nouvelElement);
        this.nomField.setText("");
        this.prenomField.setText("");
        this.quantiteField.setText("");
        this.ageField.setText("");
        System.out.println("L'élément a été ajouté avec succès !");
    }
    public void afficherInventaire(Label label, Stage stage) {
        String texte = "Liste des éléments :\n";
        for(int i = 0; i < this.elements.size(); ++i) {
            Element element = (Element)this.elements.get(i);
            texte += (i + 1) + ". " + element.getNom() + " " + element.getPrenom() + " (age: " + element.getAge() + ", quantité: " + element.getQuantite() + ")\n";
        }
        label.setText(texte);

        // Créer une nouvelle scène avec un label pour afficher le texte
        Label texteLabel = new Label(texte);
        VBox root = new VBox();
        root.getChildren().add(texteLabel);
        Scene scene = new Scene(root, 400, 300);

        // Afficher la nouvelle scène sous l'interface graphique principale
        Stage newStage = new Stage();
        newStage.setScene(scene);
        newStage.initOwner(stage);
        newStage.show();
    }


    public String getNom(int index) {
        return ((Element)this.elements.get(index)).getNom();
    }

    public String getPrenom(int index) {
        return ((Element)this.elements.get(index)).getPrenom();
    }

    public int getQuantite(int index) {
        return ((Element)this.elements.get(index)).getQuantite();
    }

    public int getAge(int index) {
        return ((Element)this.elements.get(index)).getAge();
    }


    public class Element {
        public String nom;
        public String prenom;
        public int quantite;
        public int age;

        public Element(String nom, String prenom, int quantite, int age) {
            this.nom = nom;
            this.prenom = prenom;
            this.quantite = quantite;
            this.age = age;
        }

        public String getNom() {
            return nom;
        }

        public void setNom(String nom) {
            this.nom = nom;
        }

        public String getPrenom() {
            return prenom;
        }

        public void setPrenom(String prenom) {
            this.prenom = prenom;
        }

        public int getQuantite() {
            return quantite;
        }

        public void setQuantite(int quantite) {
            this.quantite = quantite;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }
    }

    public static void main(String[] args) {
    launch(args);
}}