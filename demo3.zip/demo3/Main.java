package com.example.demo3;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Main extends Application {

    public void start(Stage primaryStage) {
        Button ajouterButton1 = new Button("ClassProffesseur");
        ajouterButton1.setOnAction((e) -> {
            Classe1 classe1 = new Classe1();

        });

        Button ajouterButton2 = new Button("HelloController");
        ajouterButton2.setOnAction((e) -> {
            HelloController helloController = new HelloController();
            helloController.start(primaryStage);
        });
        Button ajouterButton4 = new Button("Etudiant");
        ajouterButton4.setOnAction((e) -> {
            Etudiant Etudiant = new Etudiant();
            Etudiant.creerInterfaceGraphique();
        });

        Button ajouterButton8 = new Button("Prospects");
        ajouterButton8.setOnAction((e) -> {
            Prospects prospects = new Prospects();
            // je ne suis pas arriver a linmplementer malgre mais efford je sais pas c'est quoi la faute 
            prospects.executerProspects();
        });

        Button ajouterButton3 = new Button("Exit");
        ajouterButton3.setOnAction((e) -> {
            primaryStage.close();
        });

        Button ajouterButton5 = new Button("Show all");
        ajouterButton5.setOnAction((e) -> {
            System.out.println("Les trois boutons précédents ont été cliqués.");
        });

        GridPane root = new GridPane();
        root.setPadding(new Insets(10));
        root.setHgap(10);
        root.setVgap(10);
        root.add(ajouterButton1, 0, 0);
        root.add(ajouterButton2, 1, 0);
        root.add(ajouterButton3, 2, 0);
        root.add(ajouterButton4, 1, 1);
        root.add(ajouterButton8, 0, 1);

        Scene scene = new Scene(root, 300, 200);

        primaryStage.setTitle("App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
