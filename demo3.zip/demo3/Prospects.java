package com.example.demo3;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Optional;

public class Prospects extends Application {

    // Liste des prospects
    private ObservableList<Prospect> prospects = FXCollections.observableArrayList();
    // Les champs de saisie
    private TextField idField = new TextField();
    private TextField nomField = new TextField();
    private TextField prenomField = new TextField();
    private TextField emailField = new TextField();
    private TextField telephoneField = new TextField();
    private TextField entrepriseField = new TextField();
    private TextField posteField = new TextField();
    private TextField villeField = new TextField();
    private TextField paysField = new TextField();

    // Les boutons
    private Button ajouterButton = new Button("Ajouter");
    private Button modifierButton = new Button("Modifier");
    private Button supprimerButton = new Button("Supprimer");

    // La table des prospects
    private TableView<Prospect> table = new TableView<>();

    public static void main(String[] args) {
        launch(args);
    }


    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Gestion des prospects");

        // Création de la table
        TableColumn<Prospect, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Prospect, String> nomColumn = new TableColumn<>("Nom");
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));

        TableColumn<Prospect, String> prenomColumn = new TableColumn<>("Prénom");
        prenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenom"));

        TableColumn<Prospect, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Prospect, String> telephoneColumn = new TableColumn<>("Téléphone");
        telephoneColumn.setCellValueFactory(new PropertyValueFactory<>("telephone"));

        TableColumn<Prospect, String> entrepriseColumn = new TableColumn<>("Entreprise");
        entrepriseColumn.setCellValueFactory(new PropertyValueFactory<>("entreprise"));

        TableColumn<Prospect, String> posteColumn = new TableColumn<>("Poste");
        posteColumn.setCellValueFactory(new PropertyValueFactory<>("poste"));

        TableColumn<Prospect, String> villeColumn = new TableColumn<>("Ville");
        villeColumn.setCellValueFactory(new PropertyValueFactory<>("ville"));

        TableColumn<Prospect, String> paysColumn = new TableColumn<>("Pays");
        paysColumn.setCellValueFactory(new PropertyValueFactory<>("pays"));

        table.getColumns().addAll(idColumn, nomColumn, prenomColumn, emailColumn, telephoneColumn, entrepriseColumn, posteColumn, villeColumn, paysColumn);
        table.setItems(prospects);

        // Création du formulaire
        GridPane form = new GridPane();
        form.setPadding(new Insets(10));
        form.setHgap(10);
        form.setVgap(10);
        form.add(new Label("ID :"), 0, 0);
        form.add(idField, 1, 0);
        form.add(new Label("Nom :"), 0, 1);
        form.add(nomField, 1, 1);
        form.add(new Label("Prénom :"), 0, 2);
        form.add(prenomField, 1, 2);
        form.add(new Label("Email :"), 0, 3);
        form.add(emailField, 1, 3);
        form.add(new Label("Téléphone :"), 0, 4);
        form.add(telephoneField, 1, 4);
        form.add(new Label("Entreprise :"), 0, 5);
        form.add(entrepriseField, 1, 5);
        form.add(new Label("Poste :"), 0, 6);
        form.add(posteField, 1, 6);
        form.add(new Label("Ville :"), 0, 7);
        form.add(villeField, 1, 7);
        form.add(new Label("Pays :"), 0, 8);
        form.add(paysField, 1, 8);
        form.add(paysField, 1, 8);
        // Ajout des boutons
        GridPane buttons = new GridPane();
        buttons.setPadding(new Insets(10));
        buttons.setHgap(10);
        buttons.setVgap(10);
        buttons.add(ajouterButton, 0, 0);
        buttons.add(modifierButton, 1, 0);
        buttons.add(supprimerButton, 2, 0);

        // Création du layout principal
        GridPane root = new GridPane();
        root.setPadding(new Insets(10));
        root.setHgap(10);
        root.setVgap(10);
        root.add(form, 0, 0);
        root.add(buttons, 0, 1);

        // Ajout des événements aux boutons
        ajouterButton.setOnAction(event -> ajouterProspect());
        modifierButton.setOnAction(event -> modifierProspect());
        supprimerButton.setOnAction(event -> supprimerProspect());

        // Création de la scène
        Scene scene = new Scene(root, 800, 600);

        // Affichage de la scène
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void supprimerProspect() {
        // Récupération du prospect sélectionné
        Prospect prospect = table.getSelectionModel().getSelectedItem();
        if (prospect != null) {
            // Confirmation de la suppression
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation de suppression");
            alert.setHeaderText(null);
            alert.setContentText("Voulez-vous vraiment supprimer ce prospect ?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                // Suppression du prospect
                prospects.remove(prospect);
            }
        } else {
            // Aucun prospect sélectionné
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Sélectionner un prospect");
            alert.setHeaderText(null);
            alert.setContentText("Veuillez sélectionner un prospect à supprimer.");
            alert.showAndWait();
        }
    }

    // Méthode pour ajouter un prospect
    private void ajouterProspect() {
        // Récupération des données saisies
        int id = Integer.parseInt(idField.getText());
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String email = emailField.getText();
        String telephone = telephoneField.getText();
        String entreprise = entrepriseField.getText();
        String poste = posteField.getText();
        String ville = villeField.getText();
        String pays = paysField.getText();

        // Création d'un prospect avec les données saisies
        Prospect prospect = new Prospect(id, nom, prenom, email, telephone, entreprise, poste, ville, pays);

        // Ajout du prospect à la liste
        prospects.add(prospect);

        // Effacement des champs de saisie
        idField.clear();
        nomField.clear();
        prenomField.clear();
        emailField.clear();
        telephoneField.clear();
        entrepriseField.clear();
        posteField.clear();
        villeField.clear();
        paysField.clear();
    }

    // Méthode pour modifier un prospect
    private void modifierProspect() {
        // Récupération de l'ID saisi
        int id = Integer.parseInt(idField.getText());

        // Recherche du prospect correspondant dans la liste
        for (Prospect prospect : prospects) {
            if (prospect.getId() == id) {
                // Modification des attributs du prospect
                prospect.setNom(nomField.getText());
                prospect.setPrenom(prenomField.getText());
                prospect.setEmail(emailField.getText());
                prospect.setTelephone(telephoneField.getText());
                prospect.setEntreprise(entrepriseField.getText());
                prospect.setPoste(posteField.getText());
                prospect.setVille(villeField.getText());
                prospect.setPays(paysField.getText());

                // Mise à jour de la table
                table.refresh();
                break;
            }
        }

        // Réinitialisation des champs du formulaire
        idField.clear();
        nomField.clear();
        prenomField.clear();
        emailField.clear();
        telephoneField.clear();
        entrepriseField.clear();
        posteField.clear();
        villeField.clear();
        paysField.clear();
    }
    public void executerProspects() {
        Prospects prospects = new Prospects();
        prospects.ajouterProspect();
        prospects.supprimerProspect();
        prospects.modifierProspect();
        // ajoutez toutes les autres méthodes que vous voulez appeler dans Prospects
    }

    public class Prospect {
        private int id;
        private String nom;
        private String prenom;
        private String email;
        private String telephone;
        private String entreprise;
        private String poste;
        private String ville;
        private String pays;

        public Prospect(int id, String nom, String prenom, String email, String telephone, String entreprise, String poste, String ville, String pays) {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.email = email;
            this.telephone = telephone;
            this.entreprise = entreprise;
            this.poste = poste;
            this.ville = ville;
            this.pays = pays;
        }

        public void setNom(String text) {
            this.nom = text;
        }

        public int getId() {
            return this.id;
        }

        public void setPrenom(String text) {
            this.prenom = text;
        }

        public void setEmail(String text) {
            this.email = text;
        }

        public void setTelephone(String text) {
            this.telephone = text;
        }

        public void setEntreprise(String text) {
            this.entreprise = text;
        }

        public void setPays(String text) {
            this.pays = text;
        }

        public void setVille(String text) {
            this.ville = text;
        }

        public void setPoste(String text) {
            this.poste = text;
        }
    }



}

